/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Github, 
  Linkedin, 
  Instagram, 
  Mail, 
  ExternalLink, 
  ChevronRight, 
  Code2, 
  Cpu, 
  Globe, 
  Terminal,
  Menu,
  X
} from 'lucide-react';

// Sections components
const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Projects', href: '#projects' },
    { name: 'Skills', href: '#skills' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'py-4 glass' : 'py-6 bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <a href="#home" className="text-2xl font-bold tracking-tight">
          FARIS<span className="text-accent underline decoration-2 underline-offset-4">.</span>
        </a>

        {/* Desktop Nav */}
        <div className="hidden md:flex gap-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className="text-sm font-medium opacity-70 hover:opacity-100 transition-opacity"
            >
              {link.name}
            </a>
          ))}
        </div>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden p-2" 
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 w-full glass p-6 md:hidden flex flex-col gap-4"
          >
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href} 
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-lg font-medium"
              >
                {link.name}
              </a>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => {
  return (
    <section id="home" className="min-h-screen flex items-center pt-20">
      <div className="max-w-7xl mx-auto px-6 w-full">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-3xl"
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-accent/10 text-accent text-xs font-bold tracking-widest uppercase mb-6">
            Portfolio
          </span>
          <h1 className="text-6xl md:text-8xl font-bold tracking-tighter mb-8 text-gradient">
            Building digital <br /> experiences.
          </h1>
          <p className="text-lg md:text-xl text-neutral-400 mb-10 leading-relaxed">
            I'm Muhammad Aldi W, a developer focused on creating smooth, high-performance 
            web applications with modern tech stacks and AI integration.
          </p>
          <div className="flex flex-wrap gap-4">
            <a 
              href="#projects" 
              className="px-8 py-4 bg-white text-black rounded-full font-bold hover:bg-neutral-200 transition-colors flex items-center gap-2"
            >
              View Projects <ChevronRight size={18} />
            </a>
            <a 
              href="#contact" 
              className="px-8 py-4 border border-white/20 rounded-full font-bold hover:bg-white/5 transition-colors"
            >
              Get in Touch
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

const About = () => {
  return (
    <section id="about" className="py-32 bg-neutral-950">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-20 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
          >
            <div className="relative aspect-square rounded-2xl overflow-hidden grayscale hover:grayscale-0 transition-all duration-700 bg-neutral-800">
              {/* Placeholder for profile image */}
              <div className="absolute inset-0 flex items-center justify-center text-accent/20">
                <Github size={120} />
              </div>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
          >
            <h2 className="text-4xl font-bold mb-8">About Me</h2>
            <div className="space-y-6 text-neutral-400 text-lg">
              <p>
                As Faris Edrik P (rissss21), I have a passion for technology that translates into 
                highly functional and visually compelling web and mobile solutions.
              </p>
              <p>
                My expertise lies in modern frameworks like React and Vite, with a strong focus on 
                performance and clean code. I'm also deeply interested in AI and Machine Learning, 
                exploring how these technologies can be integrated into everyday applications.
              </p>
              <div className="grid grid-cols-2 gap-4 pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center text-accent">
                    <Globe size={20} />
                  </div>
                  <div>
                    <p className="text-xs text-neutral-500 font-bold uppercase">Location</p>
                    <p className="text-sm font-medium text-white">Indonesia</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center text-accent">
                    <Mail size={20} />
                  </div>
                  <div>
                    <p className="text-xs text-neutral-500 font-bold uppercase">Email</p>
                    <p className="text-sm font-medium text-white">farisedrik21@gmail.com</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const Skills = () => {
  const categories = [
    {
      title: 'Frontend',
      icon: <Globe size={24} />,
      skills: ['React', 'TypeScript', 'Tailwind CSS', 'Vite', 'Framer Motion']
    },
    {
      title: 'AI & ML',
      icon: <Cpu size={24} />,
      skills: ['Gemini API', 'Machine Learning', 'Data Analysis', 'Python']
    },
    {
      title: 'Development',
      icon: <Terminal size={24} />,
      skills: ['Git/GitHub', 'Mobile Dev', 'Clean Code', 'Responsive Design']
    }
  ];

  return (
    <section id="skills" className="py-32">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-20">
          <h2 className="text-4xl font-bold mb-4">Skillset</h2>
          <p className="text-neutral-500 max-w-2xl">
            A diverse toolkit built on industry standards and emerging technologies.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {categories.map((cat, i) => (
            <motion.div
              key={cat.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="p-8 rounded-3xl bg-neutral-900/50 border border-white/5 hover:border-accent/30 transition-colors group"
            >
              <div className="mb-6 text-accent group-hover:scale-110 transition-transform duration-500 inline-block">
                {cat.icon}
              </div>
              <h3 className="text-2xl font-bold mb-6">{cat.title}</h3>
              <div className="flex flex-wrap gap-2">
                {cat.skills.map((skill) => (
                  <span 
                    key={skill} 
                    className="px-4 py-1.5 bg-white/5 rounded-full text-sm font-medium text-neutral-300 border border-white/5"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Projects = () => {
  const projects = [
    {
      title: 'Portfolio Web',
      description: 'Personal showcase built with React + Vite + Tailwind.',
      tags: ['React', 'Vite', 'Tailwind'],
      link: 'https://github.com/rissss21/portofolio',
      icon: <Code2 />
    },
    {
      title: 'Birthday Page',
      description: 'A special landing page designed for celebration.',
      tags: ['HTML', 'CSS', 'JS'],
      link: 'https://github.com/rissss21/birthday-page',
      icon: <Globe />
    },
    {
      title: 'AI Dashboard',
      description: 'Conceptual project integrating Gemini for smart insights.',
      tags: ['AI', 'React', 'Gemini'],
      link: '#',
      icon: <Cpu />
    }
  ];

  return (
    <section id="projects" className="py-32 bg-neutral-950">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-8">
          <div>
            <h2 className="text-4xl font-bold mb-4">Selected Works</h2>
            <p className="text-neutral-500 max-w-md">
              A collection of projects exploring web development and creative coding.
            </p>
          </div>
          <a 
            href="https://github.com/rissss21" 
            target="_blank" 
            rel="noreferrer"
            className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest hover:text-accent transition-colors"
          >
            Explore All Repos <ExternalLink size={16} />
          </a>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {projects.map((project, i) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group"
            >
              <div className="h-64 rounded-3xl bg-neutral-900 border border-white/5 overflow-hidden mb-6 relative">
                <div className="absolute inset-0 flex items-center justify-center text-white/5 group-hover:scale-125 transition-transform duration-700">
                  {project.icon}
                </div>
                <div className="absolute inset-0 bg-neutral-950/80 p-8 flex flex-col justify-end opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="flex gap-2 mb-4">
                    {project.tags.map(t => <span key={t} className="text-[10px] font-bold px-2 py-1 bg-accent bg-neutral-800 rounded-md uppercase tracking-tighter">{t}</span>)}
                  </div>
                  <a href={project.link} target="_blank" rel="noreferrer" className="text-white font-bold flex items-center gap-2">
                    View Repository <ExternalLink size={14} />
                  </a>
                </div>
              </div>
              <h3 className="text-xl font-bold mb-2">{project.title}</h3>
              <p className="text-neutral-500 text-sm">{project.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Contact = () => {
  return (
    <section id="contact" className="py-32">
      <div className="max-w-7xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="max-w-2xl mx-auto"
        >
          <h2 className="text-6xl font-bold mb-8">Let's connect.</h2>
          <p className="text-neutral-400 text-lg mb-12">
            Interested in starting a project or just want to say hi? 
            My inbox is always open.
          </p>
          <div className="flex flex-col md:flex-row justify-center gap-4">
            <a 
              href="mailto:email_farisedrik21@gmail.com" 
              className="flex items-center justify-center gap-3 px-8 py-4 bg-accent text-white rounded-full font-bold hover:brightness-110 transition-all"
            >
              <Mail size={20} /> Send an Email
            </a>
            <div className="flex gap-4 justify-center items-center">
              {[
                { icon: <Github size={24} />, href: 'https://github.com/rissss21' },
                { icon: <Linkedin size={24} />, href: 'https://linkedin.com/in/farisedp' },
                { icon: <Instagram size={24} />, href: 'https://instagram.com/farisedrikprayoga' }
              ].map((social, i) => (
                <a 
                  key={i} 
                  href={social.href} 
                  target="_blank"
                  rel="noreferrer"
                  className="w-14 h-14 rounded-full border border-white/10 flex items-center justify-center hover:bg-white hover:text-black transition-all"
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="py-12 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
        <p className="text-neutral-500 text-sm font-medium">
          © {new Date().getFullYear()} Faris Edrik P. All rights reserved.
        </p>
        <div className="flex gap-8">
          <a href="#home" className="text-xs font-bold uppercase tracking-widest text-neutral-500 hover:text-white transition-colors">Back to Top</a>
        </div>
      </div>
    </footer>
  );
};

export default function App() {
  return (
    <div className="bg-surface overflow-x-hidden selection:bg-accent/30 selection:text-white">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Skills />
        <Projects />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
